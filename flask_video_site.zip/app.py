from flask import Flask, render_template, request, redirect, url_for, session, send_from_directory
import os, datetime
from werkzeug.utils import secure_filename
from functools import wraps

app = Flask(__name__)
app.secret_key = 'supersecretkey'

UPLOAD_FOLDER = 'static/videos'
PASSWORD_FILE = 'password.txt'
VISITOR_LOG = 'visitor_log.txt'
ADMIN_PASSWORD = 'admin123'

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)

def load_daily_password():
    with open(PASSWORD_FILE, 'r') as f:
        return f.read().strip()

def save_daily_password(new_password):
    with open(PASSWORD_FILE, 'w') as f:
        f.write(new_password)

def log_visitor(ip):
    with open(VISITOR_LOG, 'a') as f:
        f.write(f"{datetime.datetime.now()} - {ip}\n")

def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'admin_logged_in' not in session:
            return redirect(url_for('admin_login'))
        return f(*args, **kwargs)
    return decorated_function

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        password = request.form.get('password')
        if password == load_daily_password():
            session['authenticated'] = True
        else:
            return render_template('index.html', error='Incorrect password')
    if not session.get('authenticated'):
        return render_template('index.html')
    log_visitor(request.remote_addr)
    videos = os.listdir(UPLOAD_FOLDER)
    return render_template('videos.html', videos=videos)

@app.route('/video/<filename>')
def video(filename):
    return send_from_directory(UPLOAD_FOLDER, filename)

@app.route('/admin', methods=['GET', 'POST'])
def admin_login():
    if request.method == 'POST':
        if request.form.get('password') == ADMIN_PASSWORD:
            session['admin_logged_in'] = True
            return redirect(url_for('admin_panel'))
    return render_template('admin_login.html')

@app.route('/admin/panel', methods=['GET', 'POST'])
@login_required
def admin_panel():
    if request.method == 'POST':
        if 'video' in request.files:
            file = request.files['video']
            if file.filename:
                filename = secure_filename(file.filename)
                file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
        if 'new_password' in request.form:
            save_daily_password(request.form['new_password'])
    videos = os.listdir(UPLOAD_FOLDER)
    with open(VISITOR_LOG, 'r') as f:
        logs = f.readlines()
    return render_template('admin_panel.html', videos=videos, logs=logs)

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True)